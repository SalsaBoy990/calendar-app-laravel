-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: localhost
-- Létrehozás ideje: 2023. Júl 06. 03:41
-- Kiszolgáló verziója: 8.0.33-0ubuntu0.20.04.2
-- PHP verzió: 8.0.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `gulacsi`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `clients`
--

CREATE TABLE `clients` (
  `id` bigint UNSIGNED NOT NULL,
  `client_detail_id` bigint UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('company','private person') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'company',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `clients`
--

INSERT INTO `clients` (`id`, `client_detail_id`, `name`, `address`, `type`, `created_at`, `updated_at`) VALUES
(4, 5, 'MAHART Zrt.', 'Tápé, Komp u. 1.', 'company', '2023-05-21 18:12:47', '2023-05-22 22:27:23'),
(5, 4, 'Florin Group Kft.', 'Szeged, Fonógyári út 65.', 'company', '2023-05-21 18:12:47', '2023-05-22 17:23:39'),
(6, 3, 'Magyar Antal', 'Tápé, Barack u. 10.', 'private person', '2023-05-21 18:12:47', '2023-05-22 17:15:52'),
(41, 10, 'drtjdttjjrt', 'tjrtjtjtjtjtj', 'private person', '2023-06-21 01:28:50', '2023-06-21 01:28:50'),
(42, NULL, 'zsrhszsh srhrjsj', 'srjrsjjsrrjs rsjj rsjjsrj', 'company', '2023-06-25 09:43:32', '2023-06-25 09:43:32');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `client_details`
--

CREATE TABLE `client_details` (
  `id` bigint UNSIGNED NOT NULL,
  `contact_person` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `client_details`
--

INSERT INTO `client_details` (`id`, `contact_person`, `phone_number`, `email`, `tax_number`, `created_at`, `updated_at`) VALUES
(3, 'János Vitéz', '+36 20 1234567', 'antal@example.hu', NULL, '2023-05-22 17:15:52', '2023-05-22 17:15:52'),
(4, 'Nagy Kicsi Richárd 3', '+36201234567', NULL, '2542546266', '2023-05-22 17:23:39', '2023-06-21 01:28:38'),
(5, 'John Doe', NULL, NULL, '47473473838', '2023-05-22 22:27:23', '2023-05-22 22:27:37'),
(10, NULL, NULL, NULL, '357357577', '2023-06-21 01:28:50', '2023-06-21 01:28:50');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `events`
--

CREATE TABLE `events` (
  `event_id` bigint UNSIGNED NOT NULL,
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` bigint UNSIGNED DEFAULT NULL,
  `end` timestamp NULL DEFAULT NULL,
  `start` timestamp NULL DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','opened','completed','closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'opened',
  `is_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `rrule` json DEFAULT NULL,
  `duration` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `backgroundColor` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `events`
--

INSERT INTO `events` (`event_id`, `id`, `client_id`, `end`, `start`, `description`, `status`, `is_recurring`, `rrule`, `duration`, `backgroundColor`) VALUES
(12, '7740781a-9840-4a76-81d5-b4244076e355', 4, '2023-06-30 10:30:00', '2023-06-30 06:00:00', '', 'opened', 1, '{\"freq\": \"weekly\", \"until\": \"2025-01-03\", \"dtstart\": \"2023-06-12T08:00\", \"interval\": 1, \"byweekday\": \"Mo\"}', '04:00:00', '#c90000'),
(17, 'a942786f-4989-4e7c-a3cd-20919c5118c6', 5, '2023-07-15 08:30:00', '2023-07-15 05:30:00', '', 'opened', 0, NULL, NULL, '#c90000'),
(18, 'c393d7ed-0683-4c26-b50b-48f5e32eca80', 6, '2023-07-16 10:30:00', '2023-07-16 04:30:00', '', 'opened', 0, NULL, NULL, '#c90000'),
(19, '471755da-8c13-466b-ab09-d9c236f37a37', 6, '2023-12-04 10:00:00', '2023-12-04 06:30:00', '', 'opened', 0, NULL, NULL, '#c90000'),
(21, '490a4ce9-9330-4b6d-b82e-dc70c5d0fab3', 5, '2023-07-15 11:30:00', '2023-07-15 09:00:00', '', 'opened', 0, NULL, NULL, '#c90000'),
(22, '456680e1-0082-48c9-8502-fad8e9269d9f', 4, '2023-07-17 14:30:00', '2023-07-17 08:30:00', '', 'opened', 0, NULL, NULL, '#c90000'),
(23, '04fd6a0b-b3ae-4de1-ab05-efd9e6e5d0b2', 5, '2023-07-18 13:00:00', '2023-07-18 06:00:00', '', 'opened', 0, NULL, NULL, '#c90000'),
(24, 'e6f8b3a0-42db-4f77-9bba-c83834899fb7', 5, '2023-07-13 17:30:00', '2023-07-13 11:30:00', '', 'opened', 0, NULL, NULL, '#c90000'),
(25, 'a8b7419c-c16f-4aac-89c8-a9d0e08749a0', 6, '2023-07-16 15:00:00', '2023-07-16 11:00:00', 'tjtjtktk', 'opened', 0, NULL, NULL, '#c90000'),
(26, '57c955ea-2471-4f63-a830-092f6b2110f3', 4, '2023-07-05 18:30:00', '2023-07-05 12:00:00', '', 'opened', 0, NULL, NULL, '#c90000'),
(27, '8a6ef8f4-743d-41e5-8a2a-5e5067ccc600', 5, '2023-07-09 17:30:00', '2023-07-09 12:00:00', '', 'opened', 0, NULL, NULL, '#c90000'),
(32, '3b0ed68b-c32c-4c63-9644-3ea2f5a635a4', 4, '2023-06-20 00:30:00', '2023-06-19 20:00:00', '', 'opened', 0, NULL, NULL, NULL),
(33, '0193dbf6-9f23-46f0-9a3c-2d0ebf8ffcb9', 5, '2023-06-21 03:00:00', '2023-06-20 23:00:00', '', 'opened', 0, NULL, NULL, NULL),
(36, '07d4322b-586e-4094-8cd0-4a226036162f', 4, '2023-07-05 10:00:00', '2023-07-04 06:00:00', 'Teszt', 'opened', 0, NULL, NULL, NULL),
(37, 'd26ad1b8-4600-460f-abec-b6be63b792bc', 6, '2023-07-03 13:30:00', '2023-07-03 10:30:00', '', 'opened', 0, NULL, NULL, NULL),
(38, '0edc3989-6a8c-4758-8c6d-57cc241025b9', 5, '2023-07-07 09:00:00', '2023-07-07 06:30:00', '', 'opened', 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_05_01_223215_create_roles_table', 1),
(6, '2023_05_01_223243_create_permissions_table', 1),
(7, '2023_05_01_223625_create_users_permissions_table', 1),
(8, '2023_05_01_224016_create_users_roles_table', 1),
(9, '2023_05_01_224108_create_roles_permissions_table', 1),
(10, '2023_05_06_172002_make_slug_column_unique_in_roles_permissions_table', 1),
(11, '2023_05_08_000117_create_user_codes_table', 1),
(12, '2023_05_08_221743_add_enable_2fa_column_to_users_table', 1),
(13, '2023_05_08_232508_add_role_id_fk_to_users_table', 1),
(14, '2023_05_09_003741_drop_users_roles_table', 1),
(15, '2023_05_09_011226_change_role_id_to_have_defaults_in_users_table', 1),
(16, '2023_05_09_213936_create_events_table', 1),
(17, '2023_05_10_202535_create_users_events_table', 1),
(21, '2023_05_16_180729_add_color_column_to_events_table', 2),
(30, '2023_05_16_195923_create_worker_availabilities_table', 3),
(31, '2023_05_17_010233_add_availability_fk_to_users_table', 3),
(38, '2023_05_18_183330_add_rrule_column_to_events_table', 4),
(39, '2023_05_18_193142_add_duration_column_to_events_table', 5),
(40, '2023_05_19_225149_add_is_recurring_column_to_events_table', 6),
(45, '2023_05_21_214221_create_clients_table', 7),
(46, '2023_05_21_215520_add_client_id_fk_to_events_table', 8),
(48, '2023_05_21_220335_add_type_column_to_clients_table', 9),
(56, '2023_05_22_013710_create_client_details_table', 10),
(57, '2023_05_22_014153_add_client_details_id_fk_to_clients_table', 10),
(58, '2023_05_23_000657_drop_title_address_from_events_table', 11),
(60, '2023_06_15_004700_create_workers_table', 12),
(61, '2023_06_15_005412_add_worker_id_fk_to_worker_availabilities_table', 13),
(63, '2023_06_15_014825_create_workers_events_table', 14),
(65, '2023_06_15_220839_drop_start_end_columns_from_events_table', 15),
(66, '2023_06_15_221025_add_timestamps_to_events_table', 15),
(67, '2023_06_16_014904_drop_start_end_user_id_columns_from_worker_availabilities_table', 16),
(68, '2023_06_16_015120_add_timestamps_to_worker_availabilities_table', 16),
(70, '2023_06_19_191949_drop_order_column_from_clients_table', 17),
(71, '2023_06_19_193023_drop_availability_id_fk_column_from_workers_table', 18),
(73, '2023_06_19_212906_delete_bg_color_column_from_worker_availabilities_table', 19),
(84, '2023_06_20_035842_make_columns_nullable_in_workers_table', 20),
(85, '2023_06_20_154045_alter_event_id_column_fk_in_clients_table', 20),
(88, '2023_06_20_164822_add_event_id_fk_in_clients_table', 21),
(89, '2023_06_20_165348_delete_client_id_fk_in_events_table', 21),
(90, '2023_06_20_165627_add_client_id_fk_in_events_table', 22),
(91, '2023_06_20_165950_delete_event_id_fk_in_clients_table', 23),
(93, '2023_06_20_175253_drop_client_id_column_fk_in_client_details_table', 24),
(96, '2023_06_26_191016_add_bank_account_columns_to_workers_table', 25),
(97, '2023_06_26_223835_delete_worker_id_column_in_worker_availabilities_table', 25),
(99, '2023_06_26_224052_readd_worker_id_column_in_worker_availabilities_table', 26);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Manage users 2', 'manage-users', '2023-05-10 19:39:43', '2023-05-17 01:18:56'),
(2, 'Manage Account', 'manage-account', '2023-05-10 19:39:43', '2023-05-10 19:39:43'),
(3, 'Manage Events', 'manage-events', '2023-05-10 19:39:43', '2023-05-10 19:39:43'),
(4, 'Manage Roles', 'manage-roles', '2023-05-10 19:39:43', '2023-05-10 19:39:43'),
(5, 'Manage Permissions', 'manage-permissions', '2023-05-10 19:39:43', '2023-05-10 19:39:43');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `roles`
--

CREATE TABLE `roles` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `roles`
--

INSERT INTO `roles` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'administrator', '2023-05-10 19:39:43', '2023-05-10 19:39:43'),
(2, 'Worker', 'worker', '2023-05-10 19:39:43', '2023-05-10 19:39:43'),
(3, 'Super administrator', 'super-administrator', '2023-05-11 17:02:06', '2023-05-11 17:02:06');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `roles_permissions`
--

CREATE TABLE `roles_permissions` (
  `role_id` bigint UNSIGNED NOT NULL,
  `permission_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `roles_permissions`
--

INSERT INTO `roles_permissions` (`role_id`, `permission_id`) VALUES
(1, 1),
(3, 1),
(1, 2),
(2, 2),
(3, 2),
(1, 3),
(3, 3),
(3, 4),
(3, 5);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_2fa` tinyint(1) NOT NULL DEFAULT '0',
  `role_id` bigint UNSIGNED NOT NULL DEFAULT '2',
  `availability_id` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `enable_2fa`, `role_id`, `availability_id`, `created_at`, `updated_at`) VALUES
(1, 'Gulácsi András', 'gulandras90@gmail.com', NULL, '$2y$10$5kskoJoCbRJAsqBU0m2sCudZ01Z8j68ZoLWvacSXBxsmMiMiIAX4q', 'rvhZDPIi6lZgT5WCe517roWTBQDx7oP7tNGGaLJmrwHLxyVdM2874Q0UKjuN', 1, 3, NULL, '2023-05-10 19:39:44', '2023-05-22 23:15:53'),
(5, 'Szlavati Andi', 'szlavati.andrea.lyo@gmail.com', NULL, '$2y$10$AnIwEmAPxqUiZxyoU03cfO26DPNZMGqqtcJJozNORpM6VIzEwCU3.', NULL, 0, 1, NULL, '2023-05-11 17:01:18', '2023-05-12 16:19:42');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users_events`
--

CREATE TABLE `users_events` (
  `user_id` bigint UNSIGNED NOT NULL,
  `event_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users_permissions`
--

CREATE TABLE `users_permissions` (
  `user_id` bigint UNSIGNED NOT NULL,
  `permission_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `users_permissions`
--

INSERT INTO `users_permissions` (`user_id`, `permission_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `user_codes`
--

CREATE TABLE `user_codes` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `user_codes`
--

INSERT INTO `user_codes` (`id`, `user_id`, `code`, `created_at`, `updated_at`) VALUES
(1, 1, '349435', '2023-05-11 14:30:20', '2023-07-06 01:26:26');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `workers`
--

CREATE TABLE `workers` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_account_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_account_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `workers`
--

INSERT INTO `workers` (`id`, `name`, `email`, `phone`, `bank_account_name`, `bank_account_number`, `created_at`, `updated_at`) VALUES
(1, 'Klemen Tina', 'klemen@tina.hu', '+3620134567', NULL, NULL, '2023-06-14 23:31:42', '2023-06-14 23:31:42'),
(3, 'Jon Bull', 'john@bull.hu', '+362035463574', NULL, NULL, '2023-06-14 23:34:03', '2023-06-14 23:34:03'),
(5, 'Teszt Elek', 'teszt@elek.hu', '', NULL, NULL, '2023-06-21 01:29:15', '2023-06-21 01:29:15'),
(8, 'Nagy Pál', 'sdrgjlgsjrl@drh.hu', '', NULL, NULL, '2023-06-26 17:43:41', '2023-06-26 17:58:00');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `workers_events`
--

CREATE TABLE `workers_events` (
  `worker_id` bigint UNSIGNED NOT NULL,
  `event_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `workers_events`
--

INSERT INTO `workers_events` (`worker_id`, `event_id`) VALUES
(1, 12),
(3, 12),
(5, 12),
(1, 17),
(1, 18),
(3, 19),
(1, 21),
(3, 21),
(5, 21),
(1, 22),
(1, 23),
(3, 23),
(1, 24),
(3, 24),
(3, 25),
(3, 26),
(3, 27),
(1, 32),
(1, 33),
(3, 33),
(1, 36),
(3, 36),
(5, 37),
(8, 37),
(1, 38);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `worker_availabilities`
--

CREATE TABLE `worker_availabilities` (
  `availability_id` bigint UNSIGNED NOT NULL,
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `worker_id` bigint UNSIGNED DEFAULT NULL,
  `end` timestamp NULL DEFAULT NULL,
  `start` timestamp NULL DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `worker_availabilities`
--

INSERT INTO `worker_availabilities` (`availability_id`, `id`, `worker_id`, `end`, `start`, `description`) VALUES
(12, '25bf9865-2268-4d8d-ad6e-e422c00ab21f', 1, '2023-06-27 11:00:00', '2023-06-27 07:00:00', NULL);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `clients_name_unique` (`name`),
  ADD KEY `clients_client_detail_id_foreign` (`client_detail_id`);

--
-- A tábla indexei `client_details`
--
ALTER TABLE `client_details`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`),
  ADD UNIQUE KEY `events_id_unique` (`id`),
  ADD KEY `events_client_id_foreign` (`client_id`);

--
-- A tábla indexei `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- A tábla indexei `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- A tábla indexei `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_slug_unique` (`slug`);

--
-- A tábla indexei `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- A tábla indexei `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_slug_unique` (`slug`);

--
-- A tábla indexei `roles_permissions`
--
ALTER TABLE `roles_permissions`
  ADD PRIMARY KEY (`role_id`,`permission_id`),
  ADD KEY `roles_permissions_permission_id_foreign` (`permission_id`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_role_id_foreign` (`role_id`),
  ADD KEY `users_availability_id_foreign` (`availability_id`);

--
-- A tábla indexei `users_events`
--
ALTER TABLE `users_events`
  ADD PRIMARY KEY (`user_id`,`event_id`),
  ADD KEY `users_events_event_id_foreign` (`event_id`);

--
-- A tábla indexei `users_permissions`
--
ALTER TABLE `users_permissions`
  ADD PRIMARY KEY (`user_id`,`permission_id`),
  ADD KEY `users_permissions_permission_id_foreign` (`permission_id`);

--
-- A tábla indexei `user_codes`
--
ALTER TABLE `user_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_codes_user_id_foreign` (`user_id`);

--
-- A tábla indexei `workers`
--
ALTER TABLE `workers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `workers_email_unique` (`email`);

--
-- A tábla indexei `workers_events`
--
ALTER TABLE `workers_events`
  ADD PRIMARY KEY (`worker_id`,`event_id`),
  ADD KEY `workers_events_event_id_foreign` (`event_id`);

--
-- A tábla indexei `worker_availabilities`
--
ALTER TABLE `worker_availabilities`
  ADD PRIMARY KEY (`availability_id`),
  ADD UNIQUE KEY `worker_availabilities_id_unique` (`id`),
  ADD KEY `worker_availabilities_worker_id_foreign` (`worker_id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT a táblához `client_details`
--
ALTER TABLE `client_details`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT a táblához `events`
--
ALTER TABLE `events`
  MODIFY `event_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT a táblához `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT a táblához `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT a táblához `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT a táblához `user_codes`
--
ALTER TABLE `user_codes`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT a táblához `workers`
--
ALTER TABLE `workers`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT a táblához `worker_availabilities`
--
ALTER TABLE `worker_availabilities`
  MODIFY `availability_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `clients_client_detail_id_foreign` FOREIGN KEY (`client_detail_id`) REFERENCES `client_details` (`id`) ON DELETE CASCADE;

--
-- Megkötések a táblához `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE;

--
-- Megkötések a táblához `roles_permissions`
--
ALTER TABLE `roles_permissions`
  ADD CONSTRAINT `roles_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `roles_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Megkötések a táblához `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_availability_id_foreign` FOREIGN KEY (`availability_id`) REFERENCES `worker_availabilities` (`availability_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Megkötések a táblához `users_events`
--
ALTER TABLE `users_events`
  ADD CONSTRAINT `users_events_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `users_events_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Megkötések a táblához `users_permissions`
--
ALTER TABLE `users_permissions`
  ADD CONSTRAINT `users_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `users_permissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Megkötések a táblához `user_codes`
--
ALTER TABLE `user_codes`
  ADD CONSTRAINT `user_codes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Megkötések a táblához `workers_events`
--
ALTER TABLE `workers_events`
  ADD CONSTRAINT `workers_events_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `workers_events_worker_id_foreign` FOREIGN KEY (`worker_id`) REFERENCES `workers` (`id`) ON DELETE CASCADE;

--
-- Megkötések a táblához `worker_availabilities`
--
ALTER TABLE `worker_availabilities`
  ADD CONSTRAINT `worker_availabilities_worker_id_foreign` FOREIGN KEY (`worker_id`) REFERENCES `workers` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
