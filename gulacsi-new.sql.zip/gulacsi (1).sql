-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Gép: localhost:3306
-- Létrehozás ideje: 2023. Máj 23. 18:44
-- Kiszolgáló verziója: 8.0.33-0ubuntu0.20.04.2
-- PHP verzió: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `gulacsi`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `clients`
--

CREATE TABLE `clients` (
  `id` bigint UNSIGNED NOT NULL,
  `client_detail_id` bigint UNSIGNED DEFAULT NULL,
  `event_id` bigint UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('company','private person') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'company',
  `order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `clients`
--

INSERT INTO `clients` (`id`, `client_detail_id`, `event_id`, `name`, `address`, `type`, `order`, `created_at`, `updated_at`) VALUES
(4, 5, NULL, 'MAHART Zrt.', 'Tápé, Komp u. 1.', 'company', 1, '2023-05-21 18:12:47', '2023-05-22 22:27:23'),
(5, 4, NULL, 'Florin Group Kft.', 'Szeged, Fonógyári út 65.', 'company', 2, '2023-05-21 18:12:47', '2023-05-22 17:23:39'),
(6, 3, NULL, 'Magyar Antal', 'Tápé, Barack u. 10.', 'private person', 3, '2023-05-21 18:12:47', '2023-05-22 17:15:52');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `client_details`
--

CREATE TABLE `client_details` (
  `id` bigint UNSIGNED NOT NULL,
  `client_id` bigint UNSIGNED DEFAULT NULL,
  `contact_person` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `client_details`
--

INSERT INTO `client_details` (`id`, `client_id`, `contact_person`, `phone_number`, `email`, `tax_number`, `created_at`, `updated_at`) VALUES
(3, 6, 'János Vitéz', '+36 20 1234567', 'antal@example.hu', NULL, '2023-05-22 17:15:52', '2023-05-22 17:15:52'),
(4, 5, 'Nagy Kicsi Richárd', NULL, NULL, '2542546266', '2023-05-22 17:23:39', '2023-05-22 22:27:54'),
(5, 4, 'John Doe', NULL, NULL, '47473473838', '2023-05-22 22:27:23', '2023-05-22 22:27:37');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `events`
--

CREATE TABLE `events` (
  `event_id` bigint UNSIGNED NOT NULL,
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `end` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','opened','completed','closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'opened',
  `is_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `rrule` json DEFAULT NULL,
  `duration` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `backgroundColor` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_id` bigint UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `events`
--

INSERT INTO `events` (`event_id`, `id`, `start`, `end`, `description`, `status`, `is_recurring`, `rrule`, `duration`, `backgroundColor`, `client_id`) VALUES
(1, '630959f6-e0f7-4025-b00d-714c845d3a43', '2023-05-24', NULL, 'etiam elit eget natum deseruisse offendit', 'opened', 0, NULL, NULL, NULL, 5),
(2, '30128aa5-bb6a-46cc-ab4a-dc771a76d434', '2023-05-25T11:30:00', '2023-05-25T15:30:00', 'netus erroribus autem ridiculus idque fermentum lorem', 'closed', 0, NULL, NULL, '#c90000', 5),
(3, '948ac5b8-edee-484a-a164-7a73c31c0efc', '2023-05-23T08:30:00+02:00', '2023-05-23T18:30:00+02:00', 'necessitatibus interdum voluptatibus magna nominavi delenit', 'completed', 0, NULL, NULL, '#0f5d2a', 5),
(6, '339c6094-7821-4409-8cae-03b132638e20', '2023-05-27T08:00:00', '2023-05-27T13:00:00', 'Ez egy gyors takarítás 123', 'completed', 0, NULL, NULL, '#c200bb', 6),
(7, '385c74a2-1918-4460-a00f-fe3536727e61', '2023-05-26T09:00:00', '2023-05-26T14:00:00', 'egegegegeg', 'closed', 0, NULL, NULL, '#62626b', 5),
(8, 'b37cd14a-96ff-4425-955e-275bac4cad55', '2023-05-25T09:30:00+02:00', '2023-05-25T11:30:00+02:00', '', 'pending', 0, NULL, NULL, '#025370', 4),
(12, '7740781a-9840-4a76-81d5-b4244076e355', '2023-05-22T09:30:00+02:00', '2023-05-22T12:30:00+02:00', 'dfgsdr', 'pending', 1, '{\"freq\": \"weekly\", \"until\": \"2023-07-03\", \"dtstart\": \"2023-05-01T10:00\", \"interval\": 1, \"byweekday\": \"Mo\"}', '03:00:00', '#025370', 4);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_05_01_223215_create_roles_table', 1),
(6, '2023_05_01_223243_create_permissions_table', 1),
(7, '2023_05_01_223625_create_users_permissions_table', 1),
(8, '2023_05_01_224016_create_users_roles_table', 1),
(9, '2023_05_01_224108_create_roles_permissions_table', 1),
(10, '2023_05_06_172002_make_slug_column_unique_in_roles_permissions_table', 1),
(11, '2023_05_08_000117_create_user_codes_table', 1),
(12, '2023_05_08_221743_add_enable_2fa_column_to_users_table', 1),
(13, '2023_05_08_232508_add_role_id_fk_to_users_table', 1),
(14, '2023_05_09_003741_drop_users_roles_table', 1),
(15, '2023_05_09_011226_change_role_id_to_have_defaults_in_users_table', 1),
(16, '2023_05_09_213936_create_events_table', 1),
(17, '2023_05_10_202535_create_users_events_table', 1),
(21, '2023_05_16_180729_add_color_column_to_events_table', 2),
(30, '2023_05_16_195923_create_worker_availabilities_table', 3),
(31, '2023_05_17_010233_add_availability_fk_to_users_table', 3),
(38, '2023_05_18_183330_add_rrule_column_to_events_table', 4),
(39, '2023_05_18_193142_add_duration_column_to_events_table', 5),
(40, '2023_05_19_225149_add_is_recurring_column_to_events_table', 6),
(45, '2023_05_21_214221_create_clients_table', 7),
(46, '2023_05_21_215520_add_client_id_fk_to_events_table', 8),
(48, '2023_05_21_220335_add_type_column_to_clients_table', 9),
(56, '2023_05_22_013710_create_client_details_table', 10),
(57, '2023_05_22_014153_add_client_details_id_fk_to_clients_table', 10),
(58, '2023_05_23_000657_drop_title_address_from_events_table', 11);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Manage users 2', 'manage-users', '2023-05-10 19:39:43', '2023-05-17 01:18:56'),
(2, 'Manage Account', 'manage-account', '2023-05-10 19:39:43', '2023-05-10 19:39:43'),
(3, 'Manage Events', 'manage-events', '2023-05-10 19:39:43', '2023-05-10 19:39:43'),
(4, 'Manage Roles', 'manage-roles', '2023-05-10 19:39:43', '2023-05-10 19:39:43'),
(5, 'Manage Permissions', 'manage-permissions', '2023-05-10 19:39:43', '2023-05-10 19:39:43'),
(8, 'ftjjftfj', 'fzjfzjfzjzjzj', '2023-05-17 01:19:04', '2023-05-17 01:19:04');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `roles`
--

CREATE TABLE `roles` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `roles`
--

INSERT INTO `roles` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'administrator', '2023-05-10 19:39:43', '2023-05-10 19:39:43'),
(2, 'Worker', 'worker', '2023-05-10 19:39:43', '2023-05-10 19:39:43'),
(3, 'Super administrator', 'super-administrator', '2023-05-11 17:02:06', '2023-05-11 17:02:06');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `roles_permissions`
--

CREATE TABLE `roles_permissions` (
  `role_id` bigint UNSIGNED NOT NULL,
  `permission_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `roles_permissions`
--

INSERT INTO `roles_permissions` (`role_id`, `permission_id`) VALUES
(1, 1),
(3, 1),
(1, 2),
(2, 2),
(3, 2),
(1, 3),
(3, 3),
(3, 4),
(3, 5),
(2, 8);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_2fa` tinyint(1) NOT NULL DEFAULT '0',
  `role_id` bigint UNSIGNED NOT NULL DEFAULT '2',
  `availability_id` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `enable_2fa`, `role_id`, `availability_id`, `created_at`, `updated_at`) VALUES
(1, 'Gulácsi András', 'gulandras90@gmail.com', NULL, '$2y$10$5kskoJoCbRJAsqBU0m2sCudZ01Z8j68ZoLWvacSXBxsmMiMiIAX4q', 'aB5C2I6H2ES5n2NuG7fxng3X4rqlwhBEclzwh1ndXSpmjuCKyce3LjVSbUFd', 1, 3, NULL, '2023-05-10 19:39:44', '2023-05-22 23:15:53'),
(2, 'John Doe', 'john@doe.com', NULL, '$2y$10$6Jb9jTJ4sJiexsQ6apSKDuCOk/dc/c09xoDF6VeEWawKJwiD58D8e', NULL, 0, 2, NULL, '2023-05-10 19:39:44', '2023-05-10 19:39:44'),
(3, 'Mike Thomas', 'mike@thomas.com', NULL, '$2y$10$ux/rafbCMbrqr52pgwDKK.LX.LsIMDTxgrCW5lwHT81Gly3FJcc2G', NULL, 0, 2, NULL, '2023-05-10 19:39:44', '2023-05-10 19:39:44'),
(5, 'Szlavati Andi', 'szlavati.andrea.lyo@gmail.com', NULL, '$2y$10$AnIwEmAPxqUiZxyoU03cfO26DPNZMGqqtcJJozNORpM6VIzEwCU3.', NULL, 0, 1, NULL, '2023-05-11 17:01:18', '2023-05-12 16:19:42');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users_events`
--

CREATE TABLE `users_events` (
  `user_id` bigint UNSIGNED NOT NULL,
  `event_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `users_events`
--

INSERT INTO `users_events` (`user_id`, `event_id`) VALUES
(2, 2),
(3, 2),
(2, 3),
(2, 6),
(3, 6),
(2, 7),
(2, 8),
(2, 12),
(3, 12);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users_permissions`
--

CREATE TABLE `users_permissions` (
  `user_id` bigint UNSIGNED NOT NULL,
  `permission_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `users_permissions`
--

INSERT INTO `users_permissions` (`user_id`, `permission_id`) VALUES
(1, 1),
(3, 1),
(1, 2),
(2, 2),
(1, 3),
(1, 4),
(1, 5);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `user_codes`
--

CREATE TABLE `user_codes` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `user_codes`
--

INSERT INTO `user_codes` (`id`, `user_id`, `code`, `created_at`, `updated_at`) VALUES
(1, 1, '174408', '2023-05-11 14:30:20', '2023-05-22 23:16:27');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `worker_availabilities`
--

CREATE TABLE `worker_availabilities` (
  `availability_id` bigint UNSIGNED NOT NULL,
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `start` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `end` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `backgroundColor` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `worker_availabilities`
--

INSERT INTO `worker_availabilities` (`availability_id`, `id`, `user_id`, `start`, `end`, `description`, `backgroundColor`) VALUES
(1, '19c8d59a-b72f-47a1-a3da-91d9886d7d9b', 2, '2023-05-24T08:30', '2023-05-24T14:30', 'Ez egy teszt', '#7c5cff'),
(3, '7c8b3989-bda4-49a1-b8c8-0bf21a5b2327', 3, '2023-05-26T08:30', '2023-05-26T17:30', 'tttt', '#007bff');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `clients_name_unique` (`name`),
  ADD KEY `clients_event_id_foreign` (`event_id`),
  ADD KEY `clients_client_detail_id_foreign` (`client_detail_id`);

--
-- A tábla indexei `client_details`
--
ALTER TABLE `client_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_details_client_id_foreign` (`client_id`);

--
-- A tábla indexei `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`),
  ADD UNIQUE KEY `events_id_unique` (`id`),
  ADD KEY `events_client_id_foreign` (`client_id`);

--
-- A tábla indexei `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- A tábla indexei `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- A tábla indexei `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_slug_unique` (`slug`);

--
-- A tábla indexei `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- A tábla indexei `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_slug_unique` (`slug`);

--
-- A tábla indexei `roles_permissions`
--
ALTER TABLE `roles_permissions`
  ADD PRIMARY KEY (`role_id`,`permission_id`),
  ADD KEY `roles_permissions_permission_id_foreign` (`permission_id`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_role_id_foreign` (`role_id`),
  ADD KEY `users_availability_id_foreign` (`availability_id`);

--
-- A tábla indexei `users_events`
--
ALTER TABLE `users_events`
  ADD PRIMARY KEY (`user_id`,`event_id`),
  ADD KEY `users_events_event_id_foreign` (`event_id`);

--
-- A tábla indexei `users_permissions`
--
ALTER TABLE `users_permissions`
  ADD PRIMARY KEY (`user_id`,`permission_id`),
  ADD KEY `users_permissions_permission_id_foreign` (`permission_id`);

--
-- A tábla indexei `user_codes`
--
ALTER TABLE `user_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_codes_user_id_foreign` (`user_id`);

--
-- A tábla indexei `worker_availabilities`
--
ALTER TABLE `worker_availabilities`
  ADD PRIMARY KEY (`availability_id`),
  ADD UNIQUE KEY `worker_availabilities_id_unique` (`id`),
  ADD KEY `worker_availabilities_user_id_foreign` (`user_id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT a táblához `client_details`
--
ALTER TABLE `client_details`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT a táblához `events`
--
ALTER TABLE `events`
  MODIFY `event_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT a táblához `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT a táblához `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT a táblához `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT a táblához `user_codes`
--
ALTER TABLE `user_codes`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT a táblához `worker_availabilities`
--
ALTER TABLE `worker_availabilities`
  MODIFY `availability_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `clients_client_detail_id_foreign` FOREIGN KEY (`client_detail_id`) REFERENCES `client_details` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `clients_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`);

--
-- Megkötések a táblához `client_details`
--
ALTER TABLE `client_details`
  ADD CONSTRAINT `client_details_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE;

--
-- Megkötések a táblához `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL;

--
-- Megkötések a táblához `roles_permissions`
--
ALTER TABLE `roles_permissions`
  ADD CONSTRAINT `roles_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `roles_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Megkötések a táblához `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_availability_id_foreign` FOREIGN KEY (`availability_id`) REFERENCES `worker_availabilities` (`availability_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Megkötések a táblához `users_events`
--
ALTER TABLE `users_events`
  ADD CONSTRAINT `users_events_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `users_events_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Megkötések a táblához `users_permissions`
--
ALTER TABLE `users_permissions`
  ADD CONSTRAINT `users_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `users_permissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Megkötések a táblához `user_codes`
--
ALTER TABLE `user_codes`
  ADD CONSTRAINT `user_codes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Megkötések a táblához `worker_availabilities`
--
ALTER TABLE `worker_availabilities`
  ADD CONSTRAINT `worker_availabilities_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
